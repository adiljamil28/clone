import Image from "next/image";

export default function Web() {
  return (
    <main className="">
      
      <h1>Web Next</h1>
    
    </main>
  );
}
